// שומר את הכתובת של התוכנה כדי שהתוסף ידע לאן לשלוח (במקרה שהיא נסגרה)
chrome.storage.local.set({ nfAppUrl: window.location.href });

// מאותת לתוכנה (מבפנים) שהתוסף מותקן ופועל בהצלחה
document.documentElement.setAttribute('data-nf-extension', 'installed');

// מאזין לבקשות מהתוסף להזרקת הכתובת
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'inject_url') {
        injectWhenReady(request.url);
    }
});

function injectWhenReady(url) {
    const checkInterval = setInterval(() => {
        const input = document.getElementById('youtube-url');
        const mainContent = document.getElementById('main-content');

        if (input && !input.disabled && mainContent && mainContent.style.display !== 'none') {
            clearInterval(checkInterval);
            input.value = url;
            input.focus();
            input.dispatchEvent(new Event('input', { bubbles: true }));
            
            // אפקט חזותי קצר שמראה שהקישור הוזרק
            input.style.transition = "background-color 0.2s";
            input.style.backgroundColor = "#4d90b3";
            setTimeout(() => {
                input.style.backgroundColor = "";
            }, 400);
        }
    }, 50);
}