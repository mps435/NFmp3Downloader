const EXT_VERSION = 0.1; // הגרסה הנוכחית של התוסף

// --- זיהוי שפת הדפדפן והגדרת מילון דינמי ---
const userLang = navigator.language.startsWith('he') ? 'he' : 'en';
const strings = {
    en: {
        btnText: "Download",
        btnUpdate: "Update Ext ⚠️",
        updateAlert: "Your extension version is too old and no longer supported.\nPlease open the software settings and install the updated extension.",
        permAlert: "⚠️ The extension requires special permission to communicate with the software on your computer.\n\nThe settings page is now opening in a new tab. Please scroll down and turn on:\n'Allow access to file URLs'.\n\nAfter that, you can return here and download freely!",
        noPathAlert: "The extension doesn't know where the software is installed yet.\nPlease open the software manually (via desktop or bookmark) at least once so the extension can learn the path, then try again."
    },
    he: {
        btnText: "הורד",
        btnUpdate: "עדכן תוסף ⚠️",
        updateAlert: "גרסת התוסף שברשותך ישנה מדי ואינה נתמכת יותר.\nאנא פתח את חלון ההגדרות בתוכנה והתקן את התוסף המעודכן.",
        permAlert: "⚠️ התוסף דורש הרשאה מיוחדת כדי לתקשר עם התוכנה במחשב שלך.\n\nדף ההגדרות נפתח כעת בטאב חדש. אנא גלול למטה והפעל את המתג:\n'אפשר גישה לכתובות אתרים של קבצים' (Allow access to file URLs).\n\nלאחר מכן תוכל לחזור לכאן ולהוריד שירים בחופשיות!",
        noPathAlert: "התוסף עדיין לא יודע היכן מותקנת התוכנה.\nאנא פתח את התוכנה ידנית (דרך שולחן העבודה או סימניה) לפחות פעם אחת כדי שהתוסף ילמד את הנתיב, ולאחר מכן נסה שוב."
    }
};
const i18n = strings[userLang];

// --- הגדרות ברירת מחדל אמינות (קשיחות בקוד) ---
let currentConfig = {
    minVersion: 0.1,
    selectors:[
        'ytd-watch-metadata ytd-menu-renderer #top-level-buttons-computed',
        'ytd-watch-metadata ytd-menu-renderer #flexible-item-buttons',
        'ytd-playlist-header-renderer ytd-menu-renderer #top-level-buttons-computed',
        'ytd-playlist-header-renderer ytd-menu-renderer #flexible-item-buttons',
        'ytd-menu-renderer #top-level-buttons-computed'
    ]
};

// טוען את ההגדרות המעודכנות מגיטהאב (אם הגיעו למסד הנתונים), אם לא - ממשיך רגיל!
chrome.storage.local.get(['extConfig'], (result) => {
    if (result.extConfig) {
        currentConfig = Object.assign(currentConfig, result.extConfig);
    }
});

function tryInjectButton() {
    const isWatch = window.location.pathname.startsWith('/watch');
    const isPlaylist = window.location.pathname.startsWith('/playlist');

    if (!isWatch && !isPlaylist) return;

    let actionBar = null;
    for (let selector of currentConfig.selectors) {
        let el = document.querySelector(selector);
        if (el && el.offsetParent !== null) {
            actionBar = el;
            break;
        }
    }

    if (!actionBar) return;
    if (document.querySelector('#nf-download-btn')) return;
    
    document.querySelectorAll('#nf-download-btn').forEach(btn => btn.remove());
    const btn = document.createElement('button');
    btn.id = 'nf-download-btn';

    // בודק אם הגרסה הנוכחית קטנה מהגרסה המינימלית שהוגדרה בגיטהאב (דורש עדכון קריטי)
    const isOutdated = currentConfig.minVersion > EXT_VERSION;

    if (isOutdated) {
        // עיצוב של אזהרת עדכון (משתמש במילון)
        btn.innerHTML = `<span style="margin-top: 1px; white-space: nowrap;">${i18n.btnUpdate}</span>`;
        btn.style.cssText = `
            background-color: #f39c12; color: white; border: none; padding: 0 16px;
            height: 36px; border-radius: 18px; cursor: pointer; font-weight: bold;
            font-family: 'Roboto', 'Arial', sans-serif; font-size: 14px;
            display: inline-flex; align-items: center; justify-content: center;
            margin-inline-end: 8px; flex: 0 0 auto; box-sizing: border-box;
        `;
        btn.onclick = () => {
            alert(i18n.updateAlert);
            chrome.runtime.sendMessage({ action: 'open_app', url: window.location.href });
        };
    } else {
        // עיצוב רגיל וסולידי של כפתור ההורדה
        btn.innerHTML = `
            <span style="margin-top: 1px; white-space: nowrap;">${i18n.btnText}</span>
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0; margin: 0 6px;">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
            </svg>
        `;
        btn.style.cssText = `
            background-color: #d85a53; color: white; border: none; padding: 0 16px;
            height: 36px; border-radius: 18px; cursor: pointer; font-weight: 500;
            font-family: 'Roboto', 'Arial', sans-serif; font-size: 14px;
            display: inline-flex; align-items: center; justify-content: center;
            margin-inline-end: 8px; transition: background-color 0.2s, opacity 0.2s;
            flex: 0 0 auto; box-sizing: border-box;
        `;

        btn.onmouseover = () => btn.style.backgroundColor = "#c44c46";
        btn.onmouseout = () => btn.style.backgroundColor = "#d85a53";
        btn.onmousedown = () => btn.style.opacity = "0.8";
        btn.onmouseup = () => btn.style.opacity = "1";

        btn.onclick = () => {
            chrome.runtime.sendMessage({ action: 'open_app', url: window.location.href });
        };
    }
    
    actionBar.prepend(btn);
}

// קבלת התראות מ-background.js
chrome.runtime.onMessage.addListener((req) => {
    if (req.action === 'alert_needs_permission') {
        alert(i18n.permAlert);
    }
    if (req.action === 'alert_no_path') {
        alert(i18n.noPathAlert);
    }
});

// מאזין לניווט הפנימי של יוטיוב (SPA)
document.addEventListener('yt-navigate-finish', () => {
    setTimeout(tryInjectButton, 300);
    setTimeout(tryInjectButton, 1000);
});

// מאזין לשינויים ב-DOM כדי לתפוס את הטעינה המאוחרת של הכפתורים
const observer = new MutationObserver(() => { tryInjectButton(); });
if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
} else {
    document.addEventListener('DOMContentLoaded', () => {
        observer.observe(document.body, { childList: true, subtree: true });
    });
}

// מעטפת ביטחון
setInterval(tryInjectButton, 1500);