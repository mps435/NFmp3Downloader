function getYoutubeCookies() {
    return new Promise((resolve) => {
        chrome.cookies.getAll({ url: 'https://www.youtube.com' }, (cookies) => {
            if (!cookies || cookies.length === 0) { resolve(null); return; }
            let fileContent = "# Netscape HTTP Cookie File\n";
            cookies.forEach(c => {
                let domain = c.domain; let incSub = domain.startsWith('.') ? "TRUE" : "FALSE";
                let secure = c.secure ? "TRUE" : "FALSE"; let exp = c.expirationDate ? Math.round(c.expirationDate) : 0;
                fileContent += `${domain}\t${incSub}\t${c.path}\t${secure}\t${exp}\t${c.name}\t${c.value}\n`;
            });
            resolve(fileContent);
        });
    });
}

chrome.action.onClicked.addListener((tab) => {
    chrome.tabs.query({ url: "file:///*/*index.html*" }, (tabs) => {
        let appTab = tabs.find(t => t.url.includes('NFmp3Downloader'));
        chrome.storage.local.get(['userConfig', 'nfAppUrl'], (result) => {
            const config = result.userConfig || { btnStyle: 'classic' };
            if (appTab) {
                chrome.tabs.update(appTab.id, { active: true });
                chrome.windows.update(appTab.windowId, { focused: true });
                chrome.tabs.sendMessage(appTab.id, { action: 'trigger_ext_settings', config });
            } else if (result.nfAppUrl) {
                chrome.tabs.create({ url: result.nfAppUrl }, (newTab) => {
                    chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
                        if (tabId === newTab.id && info.status === 'complete') {
                            chrome.tabs.onUpdated.removeListener(listener);
                            chrome.tabs.sendMessage(tabId, { action: 'trigger_ext_settings', config });
                        }
                    });
                });
            }
        });
    });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'request_ext_settings') {
        chrome.storage.local.get(['userConfig'], (result) => {
            sendResponse({ config: result.userConfig || { btnStyle: 'classic' } });
        });
        return true;
    }
    if (request.action === 'get_cookies') {
        getYoutubeCookies().then(cookies => sendResponse({ cookies }));
        return true;
    }
    if (request.action === 'set_ext_config') {
        chrome.storage.local.get(['userConfig'], (res) => {
            let uConf = res.userConfig || {}; uConf[request.key] = request.value;
            chrome.storage.local.set({ userConfig: uConf });
        });
    }
    if (request.action === 'open_app') {
        const ytUrl = request.url;
        chrome.extension.isAllowedFileSchemeAccess(async (isAllowed) => {
            if (!isAllowed) {
                chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id });
                if (sender && sender.tab) chrome.tabs.sendMessage(sender.tab.id, { action: 'alert_needs_permission' });
                return;
            }
            const cookies = await getYoutubeCookies();
            chrome.tabs.query({ url: "file:///*/*index.html*" }, (tabs) => {
                let appTab = tabs.find(t => t.url.includes('NFmp3Downloader'));
                if (appTab) {
                    chrome.tabs.update(appTab.id, { active: true });
                    chrome.windows.update(appTab.windowId, { focused: true });

                    chrome.tabs.sendMessage(appTab.id, { action: 'inject_url', url: ytUrl, cookies }, (response) => {
                        if (chrome.runtime.lastError) {
                            chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
                                if (tabId === appTab.id && info.status === 'complete') {
                                    chrome.tabs.onUpdated.removeListener(listener);
                                    chrome.tabs.sendMessage(tabId, { action: 'inject_url', url: ytUrl, cookies });
                                }
                            });
                            chrome.tabs.reload(appTab.id);
                        }
                    });
                } else {

                    chrome.storage.local.get(['nfAppUrl'], (result) => {
                        if (result.nfAppUrl) {
                            chrome.tabs.create({ url: result.nfAppUrl }, (newTab) => {
                                chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
                                    if (tabId === newTab.id && info.status === 'complete') {
                                        chrome.tabs.onUpdated.removeListener(listener);
                                        chrome.tabs.sendMessage(tabId, { action: 'inject_url', url: ytUrl, cookies });
                                    }
                                });
                            });
                        } else if (sender && sender.tab) {
                            chrome.tabs.sendMessage(sender.tab.id, { action: 'alert_no_path' });
                        }
                    });
                }
            });
        });
    }
});