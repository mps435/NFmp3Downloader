const EXT_VERSION = 0.2;
const userLang = navigator.language.startsWith('he') ? 'he' : 'en';
const i18n = { en: { btnText: "Download" }, he: { btnText: "הורד" } }[userLang];

let currentConfig = {
    selectors: [
        'ytd-watch-metadata ytd-menu-renderer #top-level-buttons-computed',
        'ytd-watch-metadata ytd-menu-renderer #flexible-item-buttons',
        'ytd-playlist-header-renderer ytd-menu-renderer #top-level-buttons-computed'
    ]
};
let userConfig = { btnStyle: 'classic' };

chrome.storage.local.get(['userConfig'], (result) => {
    if (result.userConfig) userConfig = result.userConfig;
});

function getTargetUrl(isNetube) {
    if (!isNetube) return window.location.href;
    const ytBtn = Array.from(document.querySelectorAll('a, button')).find(el => el.textContent && el.textContent.includes('פתח ב-YouTube'));
    if (ytBtn && ytBtn.tagName === 'A' && ytBtn.href.includes('youtube.com')) return ytBtn.href;
    const iframe = document.querySelector('iframe[src*="youtube.com/embed/"]');
    if (iframe) return `https://www.youtube.com/watch?v=${iframe.src.split('embed/')[1].split('?')[0]}`;
    return window.location.href;
}

function tryInjectButton() {
    const isNetube = window.location.hostname.includes('netube.co.il');
    const isWatch = window.location.pathname.startsWith('/watch');
    const isPlaylist = window.location.pathname.startsWith('/playlist');
    if (!isNetube && !isWatch && !isPlaylist) return;

    let actionBar = null;
    if (isNetube) {
        actionBar = document.querySelector('.video-page-actions');
    } else if (userConfig.btnStyle === 'floating') {
        actionBar = document.querySelector('#movie_player') || document.querySelector('.html5-video-player');
    } else {
        for (let selector of currentConfig.selectors) {
            let el = document.querySelector(selector);
            if (el && el.offsetParent !== null) { actionBar = el; break; }
        }
    }

    if (!actionBar || document.querySelector('#nf-download-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'nf-download-btn';
    const dlIcon = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>`;

    if (isNetube) {
        btn.innerHTML = `<span style="white-space: nowrap;">${i18n.btnText}</span>${dlIcon}`;
        btn.style.cssText = `
            background-color: var(--bg-card, #1E293B); color: var(--text, #F1F5F9); border: 1.5px solid var(--border, #334155);
            padding: 8px 16px; height: 40px; border-radius: 10px; cursor: pointer; font-weight: 600;
            font-family: Roboto, Rubik, Arial, sans-serif; font-size: 14px; display: inline-flex;
            align-items: center; justify-content: center; gap: 6px; margin: 0; transition: all 0.2s ease; box-sizing: border-box;
        `;
        btn.onmouseover = () => btn.style.backgroundColor = "var(--bg-hover, #334155)";
        btn.onmouseout = () => btn.style.backgroundColor = "var(--bg-card, #1E293B)";
    } else if (userConfig.btnStyle === 'official') {
        const officialIcon = `<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink: 0;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>`;
        btn.innerHTML = `${officialIcon}<span style="font-size: 14px; font-weight: 500; line-height: 1;">הורד</span>`;
        btn.style.cssText = `background-color: var(--yt-spec-button-chip-background-hover, rgba(0, 0, 0, 0.05)); color: var(--yt-spec-text-primary, #0f0f0f); border: none; border-radius: 20px; padding: 0 16px; height: 40px; font-family: "Roboto", "Arial", sans-serif; font-weight: 500; display: inline-flex; align-items: center; justify-content: center; gap: 8px; cursor: pointer; margin-inline-start: 8px; margin-inline-end: 6px; transition: background-color 0.2s; box-sizing: border-box;`;
        btn.onmouseover = () => btn.style.backgroundColor = 'var(--yt-spec-badge-chip-background, rgba(0, 0, 0, 0.1))';
        btn.onmouseout = () => btn.style.backgroundColor = 'var(--yt-spec-button-chip-background-hover, rgba(0, 0, 0, 0.05))';
    } else if (userConfig.btnStyle === 'floating') {
        btn.innerHTML = `${dlIcon} <span style="font-size: 13px;">הורד סרטון זה</span>`;
        btn.style.cssText = `position: absolute; top: 10px; right: 10px; z-index: 9999; background: rgba(44, 62, 80, 0.85); color: #ecf0f1; border: 1px solid #34495e; border-radius: 6px; padding: 6px 12px; font-family: sans-serif; display: flex; align-items: center; cursor: pointer;`;
    } else {
        btn.innerHTML = `<span style="margin-top: 1px;">הורד</span>${dlIcon}`;
        btn.style.cssText = `background-color: #d85a53; color: white; border: none; padding: 0 16px; height: 36px; border-radius: 18px; cursor: pointer; font-weight: 500; font-family: 'Roboto', Arial, sans-serif; font-size: 14px; display: inline-flex; align-items: center; margin-inline-end: 8px;`;
    }

    btn.onclick = (e) => {
        e.preventDefault(); e.stopPropagation();
        chrome.runtime.sendMessage({ action: 'open_app', url: getTargetUrl(isNetube) });
    };
    if (isNetube) {
        const channelAvatar = actionBar.querySelector('#video-ch-avatar-main');
        if (channelAvatar) channelAvatar.after(btn);
        else actionBar.prepend(btn);
    } else if (userConfig.btnStyle === 'floating') {
        actionBar.appendChild(btn);
    } else {
        actionBar.prepend(btn);
    }
}

document.addEventListener('yt-navigate-finish', () => { setTimeout(tryInjectButton, 300); setTimeout(tryInjectButton, 1000); });
const observer = new MutationObserver(() => { tryInjectButton(); });
if (document.body) { observer.observe(document.body, { childList: true, subtree: true }); }
setInterval(tryInjectButton, 1500);