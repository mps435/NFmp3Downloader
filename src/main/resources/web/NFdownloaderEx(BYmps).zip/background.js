chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'open_app') {
        const ytUrl = request.url;

        chrome.extension.isAllowedFileSchemeAccess((isAllowed) => {
            if (!isAllowed) {
                chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id });
                chrome.tabs.sendMessage(sender.tab.id, { action: 'alert_needs_permission' });
                return;
            }

            chrome.tabs.query({ url: "file:///*/*index.html*" }, (tabs) => {
                let appTab = tabs.find(t => t.url.includes('NFmp3Downloader') || t.url.includes('web/index.html'));

                if (appTab) {
                    chrome.tabs.update(appTab.id, { active: true });
                    chrome.windows.update(appTab.windowId, { focused: true });
                    chrome.tabs.sendMessage(appTab.id, { action: 'inject_url', url: ytUrl });
                } else {
                    chrome.storage.local.get(['nfAppUrl'], (result) => {
                        if (result.nfAppUrl) {
                            chrome.tabs.create({ url: result.nfAppUrl }, (newTab) => {
                                chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
                                    if (tabId === newTab.id && info.status === 'complete') {
                                        chrome.tabs.onUpdated.removeListener(listener);
                                        chrome.tabs.sendMessage(tabId, { action: 'inject_url', url: ytUrl });
                                    }
                                });
                            });
                        } else {
                            chrome.tabs.sendMessage(sender.tab.id, { action: 'alert_no_path' });
                        }
                    });
                }
            });
        });
    }
});

// --- מנגנון משיכת הגדרות חכמות מגיטהאב ---
async function updateExtensionConfig() {
    try {
        // מחפש את קובץ ההגדרות בגיטהאב. אם אין, הוא פשוט ייכשל (Catch) והתוסף ישתמש בברירת המחדל
        const url = 'https://raw.githubusercontent.com/mps435/NFmp3Downloader/main/extension-config.json';
        const res = await fetch(url, { cache: 'no-store' });
        if (res.ok) {
            const config = await res.json();
            chrome.storage.local.set({ extConfig: config });
        }
    } catch(e) {
        console.log("Using default extension config. Fetch failed or file not found.");
    }
}

// מעדכן את ההגדרות בכל פעם שהדפדפן נדלק
chrome.runtime.onStartup.addListener(updateExtensionConfig);
chrome.runtime.onInstalled.addListener(updateExtensionConfig);

// מגדיר משימה שתרוץ כל 12 שעות כדי לבדוק עדכונים מרחוק
chrome.alarms.create("fetchConfig", { periodInMinutes: 720 });
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "fetchConfig") updateExtensionConfig();
});