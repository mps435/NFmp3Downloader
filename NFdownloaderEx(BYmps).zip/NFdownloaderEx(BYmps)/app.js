chrome.storage.local.set({ nfAppUrl: window.location.href });
document.documentElement.setAttribute('data-nf-extension', 'installed');

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'inject_url') {
        injectWhenReady(request.url);
        if (request.cookies) window.postMessage({ action: 'inject_cookies', cookies: request.cookies }, '*');
    }
    if (request.action === 'trigger_ext_settings') {
        window.postMessage({ action: 'open_ext_settings_modal', config: request.config }, '*');
    }
});

function injectWhenReady(url) {
    const checkInterval = setInterval(() => {
        const input = document.getElementById('youtube-url');
        const mainContent = document.getElementById('main-content');
        if (input && !input.disabled && mainContent && mainContent.style.display !== 'none') {
            clearInterval(checkInterval); input.value = url; input.focus(); input.dispatchEvent(new Event('input', { bubbles: true }));
            input.style.transition = "background-color 0.2s"; input.style.backgroundColor = "#4d90b3"; setTimeout(() => { input.style.backgroundColor = ""; }, 400);
        }
    }, 50);
}

window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    if (event.data && event.data.action === 'request_cookies') {
        chrome.runtime.sendMessage({ action: 'get_cookies' }, (res) => {
            if (chrome.runtime.lastError || !res || !res.cookies) { window.postMessage({ action: 'cookies_unavailable' }, '*'); return; }
            window.postMessage({ action: 'inject_cookies', cookies: res.cookies }, '*');
        });
    }
    if (event.data && event.data.action === 'request_export_cookies') {
        chrome.runtime.sendMessage({ action: 'get_cookies' }, (res) => {
            window.postMessage({ action: 'export_cookies_result', cookies: res ? res.cookies : null }, '*');
        });
    }
    if (event.data && event.data.action === 'set_ext_config') {
        chrome.runtime.sendMessage(event.data);
    }
    if (event.data && event.data.action === 'request_ext_settings') {
        chrome.runtime.sendMessage({ action: 'request_ext_settings' }, (res) => {
            if (res) window.postMessage({ action: 'open_ext_settings_modal', config: res.config }, '*');
        });
    }
});
chrome.storage.local.set({ nfAppUrl: window.location.href });
document.documentElement.setAttribute('data-nf-extension', 'installed');
document.documentElement.setAttribute('data-nf-ext-version', '0.3');ד